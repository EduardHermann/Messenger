select * from messengerdb.messanges;

-- select msg, thedate from messengerdb.messanges;