-- delete from messengerdb.messanges where id = 20;

TRUNCATE table messengerdb.messanges;
